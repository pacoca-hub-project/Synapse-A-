package com.exemplo.synapse

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var web: WebView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val dens get() = resources.displayMetrics.density

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate() {
        super.onCreate()
        iniciarEmPrimeiroPlano()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            (330 * dens).toInt(), (440 * dens).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_FOCUSABLE: toques passam para o app de baixo fora da janela e o teclado não rouba foco.
            // O HTML liga o foco só quando o usuário toca no editor (setFocusable).
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * dens).toInt()
            y = (120 * dens).toInt()
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Ponte(), "Android")
            loadUrl("file:///android_asset/overlay.html")
        }
        wm.addView(web, lp)
    }

    override fun onDestroy() {
        web?.let { wm.removeView(it); it.destroy() }
        web = null
        super.onDestroy()
    }

    private fun atualizar() { web?.let { wm.updateViewLayout(it, lp) } }

    private fun iniciarEmPrimeiroPlano() {
        val canal = "synapse_overlay"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(canal, "Janela flutuante", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, canal)
            .setContentTitle("synapse A")
            .setContentText("Janela flutuante ativa")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    /** Chamado pelo JS (em outra thread), então tudo vai para a thread principal. */
    private inner class Ponte {
        @JavascriptInterface fun moveBy(dx: Float, dy: Float) = ui.post {
            val tela = resources.displayMetrics
            lp.x = (lp.x + dx * dens).toInt().coerceIn(0, tela.widthPixels - (40 * dens).toInt())
            lp.y = (lp.y + dy * dens).toInt().coerceIn(0, tela.heightPixels - (40 * dens).toInt())
            atualizar()
        }

        @JavascriptInterface fun setSize(wDp: Int, hDp: Int) = ui.post {
            lp.width = (wDp * dens).toInt()
            lp.height = (hDp * dens).toInt()
            atualizar()
        }

        @JavascriptInterface fun setFocusable(sim: Boolean) = ui.post {
            lp.flags = if (sim) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            atualizar()
        }

        @JavascriptInterface fun fechar() = ui.post { stopSelf() }
    }
}
