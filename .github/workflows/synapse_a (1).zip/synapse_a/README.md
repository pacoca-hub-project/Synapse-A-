# synapse A

Editor Lua flutuante (sobrepõe outros apps) feito com WebView + Kotlin.

## Gerar o APK pelo GitHub
1. Suba este projeto para um repositório (branch `main`).
2. Abra a aba **Actions** → **Build APK** → aguarde terminar (ou clique em **Run workflow**).
3. Baixe o APK em **Artifacts** → `synapse-A-debug`.

## Gerar localmente
```
gradle assembleDebug
```
O APK sai em `app/build/outputs/apk/debug/`.

## Estrutura
- `app/src/main/assets/index.html`: tela inicial com o botão Rodar
- `app/src/main/assets/overlay.html`: janela flutuante (abas, realce, arrastar)
- `MainActivity.kt`: pede a permissão "Sobrepor a outros apps"
- `OverlayService.kt`: desenha a janela por cima dos outros apps
