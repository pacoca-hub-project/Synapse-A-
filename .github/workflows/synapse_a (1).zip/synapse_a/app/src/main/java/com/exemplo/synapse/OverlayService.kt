package com.exemplo.synapse

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import org.json.JSONObject
import org.luaj.vm2.LuaError
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.ByteArrayOutputStream
import java.io.PrintStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class OverlayService : Service() {

    private companion object {
        const val LARGURA = 340   // dp, janela aberta
        const val ALTURA = 290
        const val BOLHA = 56      // dp, minimizada
        const val ALCA = 34       // dp, altura da barra de arrastar (topo)

        // Pequenos substitutos do Roblox para scripts Lua puros
        const val PRELUDIO = """
            unpack = unpack or table.unpack
            loadstring = loadstring or load
            typeof = type
            tick = os.time
            warn = function(...) print("[warn]", ...) end
            wait = function(t) return t or 0 end
            task = { wait = wait, spawn = function(f, ...) return f(...) end }
        """
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var raiz: Raiz? = null
    private var web: WebView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val dens get() = resources.displayMetrics.density

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate() {
        super.onCreate()
        iniciarEmPrimeiroPlano()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            (LARGURA * dens).toInt(), (ALTURA * dens).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * dens).toInt()
            y = (100 * dens).toInt()
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Ponte(), "Android")
            loadUrl("file:///android_asset/overlay.html")
        }
        raiz = Raiz(this).also {
            it.addView(web)
            wm.addView(it, lp)
        }
    }

    override fun onDestroy() {
        raiz?.let { wm.removeView(it) }
        web?.destroy()
        raiz = null
        web = null
        super.onDestroy()
    }

    private fun atualizar() { raiz?.let { wm.updateViewLayout(it, lp) } }

    private fun iniciarEmPrimeiroPlano() {
        val canal = "synapse_overlay"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(canal, "Janela flutuante", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, canal)
            .setContentTitle("synapse A")
            .setContentText("Janela flutuante ativa")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    /**
     * Arrastar feito aqui no nativo, com a posição absoluta do dedo (rawX/rawY):
     * sem ida e volta com o JS, então não treme. Só começa o arrasto na barra do topo
     * (ou na bolha inteira) e depois de passar do "slop"; toques simples seguem para o HTML.
     */
    private inner class Raiz(ctx: Context) : FrameLayout(ctx) {
        var minimizado = false
        private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var iniX = 0
        private var iniY = 0
        private var podeArrastar = false
        private var arrastando = false

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY
                    iniX = lp.x; iniY = lp.y
                    podeArrastar = minimizado || ev.y <= ALCA * dens
                    arrastando = false
                }
                MotionEvent.ACTION_MOVE -> if (podeArrastar && !arrastando &&
                    (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)
                ) {
                    arrastando = true
                    return true
                }
            }
            return false
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> if (arrastando) {
                    val tela = resources.displayMetrics
                    val min = (40 * dens).toInt()
                    lp.x = (iniX + (ev.rawX - downX)).toInt().coerceIn(0, tela.widthPixels - min)
                    lp.y = (iniY + (ev.rawY - downY)).toInt().coerceIn(0, tela.heightPixels - min)
                    atualizar()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> arrastando = false
            }
            return true
        }
    }

    /** Executa o Lua (LuaJ) fora da thread principal e devolve a saída para o HTML. */
    private fun executarLua(codigo: String) {
        Thread {
            val saida = ByteArrayOutputStream()
            val erro = AtomicBoolean(false)
            val worker = Thread {
                try {
                    val g = JsePlatform.standardGlobals()
                    g.STDOUT = PrintStream(saida, true, "UTF-8")
                    g.load(PRELUDIO, "prelude").call()
                    g.load(codigo, "script").call()
                } catch (e: LuaError) {
                    erro.set(true)
                    saida.write(("\n" + (e.message ?: "erro")).toByteArray())
                } catch (e: Throwable) {
                    erro.set(true)
                    saida.write(("\n" + e.toString()).toByteArray())
                }
            }
            worker.start()
            worker.join(5000)
            if (worker.isAlive) {
                erro.set(true)
                saida.write("\n[tempo esgotado: 5s]".toByteArray())
            }
            val txt = String(saida.toByteArray(), Charsets.UTF_8).trim().ifEmpty { "(sem saída)" }
            ui.post { web?.evaluateJavascript("onSaida(${JSONObject.quote(txt)}, ${erro.get()})", null) }
        }.start()
    }

    /** Chamado pelo JS (em outra thread), então tudo vai para a thread principal. */
    private inner class Ponte {
        @JavascriptInterface fun minimizar(min: Boolean) = ui.post {
            raiz?.minimizado = min
            lp.width = ((if (min) BOLHA else LARGURA) * dens).toInt()
            lp.height = ((if (min) BOLHA else ALTURA) * dens).toInt()
            atualizar()
        }

        @JavascriptInterface fun setFocusable(sim: Boolean) = ui.post {
            lp.flags = if (sim) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            atualizar()
        }

        @JavascriptInterface fun rodar(codigo: String) { executarLua(codigo) }

        @JavascriptInterface fun fechar() = ui.post { stopSelf() }
    }
}
