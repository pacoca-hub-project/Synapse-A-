package com.exemplo.synapse

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var aguardandoPermissao = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android 13+: permissão da notificação do serviço em primeiro plano (o app funciona mesmo se negar)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#12141c"))
            settings.javaScriptEnabled = true
            addJavascriptInterface(Ponte(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        // Voltou da tela de configurações: se a permissão foi concedida, abre a janela
        if (aguardandoPermissao && Settings.canDrawOverlays(this)) {
            aguardandoPermissao = false
            abrirJanela()
        }
    }

    private fun status(msg: String) =
        web.evaluateJavascript("onStatus(${org.json.JSONObject.quote(msg)})", null)

    private fun abrirJanela() {
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true) // mostra os outros apps por baixo da janela
    }

    private inner class Ponte {
        @JavascriptInterface fun rodar() = runOnUiThread {
            if (Settings.canDrawOverlays(this@MainActivity)) {
                abrirJanela()
            } else {
                aguardandoPermissao = true
                status("Ative \"Sobrepor a outros apps\" para o synapse A e volte.")
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
    }
}
